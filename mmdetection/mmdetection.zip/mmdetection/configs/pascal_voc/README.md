### SSD

| Backbone | Size  | Style | Lr schd | Mem (GB) | Train time (s/iter) | Inf time (fps) | box AP | Download  |
| :------: | :---: | :---: | :-----: | :------: | :-----------------: | :------------: | :----: | :-------: |
|  VGG16   |  300  | caffe |  240e   |          |                     |                |        | [model]() |
|  VGG16   |  512  | caffe |  240e   |          |                     |                |        | [model]() |
